# Qualification record — v20-r2 scoped gates passed; publication pending

Updated 2026-11-02. Public target: core `0.8.0~beta9-9`; private beta10 feedback
pilot is excluded from this installer and from the public package generation.

| Scenario | Exact installer | Actual result |
|---|---|---|
| Uninterrupted fresh ARM64, 1.5 GiB guest | v18, `108f0a71…f53334` | PASS: authenticated package transaction, native validation, empty identity, real HTTP status, radio off; 1,060.11 s |
| Uninterrupted fresh ARM64, 512 MiB allocation | Same v18 | PASS: 1,150.13 s; usable RAM 473,052 KiB, swap 0; sampled MemAvailable minimum 306,392 KiB |
| Interruption/reboot/resume | v18 | FAIL SAFE: `GetUnit` reported inactive Asterisk unit unloaded; radio remained off. Evidence retained, not counted as a pass |
| Fresh install with controlled interruption, actual reboot and same-bundle resume | v19-r4, `b2f39f27…ac4059` | PASS: 1,560.17 s; durable phase 1 exit 85/reboot, phase 2 exit 0/poweroff, same bundle/deadline, changed boot ID, state preserved, native/HTTP/empty-identity/radio-off checks |
| Synthetic legacy identity A | v19-r4 | FAIL: console connection refused after 20 retries; read-only diagnosis proved newly created /etc/allmode mode 0700 blocked the service user |
| Synthetic legacy identity B | v19-r4 | Not run; superseded by corrected v20 B qualification |
| Corrected synthetic legacy identity A | v20-r2 | PASS: 1,250.13 s; 122 preserved files, actual authenticated HTTP readiness, configuration/radio-off checks and durable result |
| Corrected synthetic legacy identity B | v20-r2 | PASS: 1,255.14 s; 122 preserved files, authenticated HTTP readiness, configuration/radio-off checks and durable result |
| Final fresh-readiness function on a separate clone of successful fresh v18 | v20-r2 function, exact `90ed40c1…0e7f1f` | PASS: 210.02 s; actual service-user access, stable PID/listener ownership and fresh read-only HTTP response; package versions and configuration bytes/owners/modes unchanged, radio off. Targeted check only, not a full v20 installation |

The v19 recovery case started from the pristine signed Debian ARM64 base and
executed fresh mode through package installation. Resume retained `mode=fresh`
and executed the full production orchestration through fresh-profile provisioning
and console commit. This covers the fresh behavior plus recovery; it is not
presented as an uninterrupted v19 timing benchmark. The 512 MiB result belongs to
v18, whose package pins are identical, not a claimed rerun of v19 at 512 MiB.

The 512 MiB guest's Linux-usable RAM differs from the physical Zero 2 W sample
(425,116 KiB usable RAM and 424,956 KiB swap). QEMU's peak host RSS of 735,344 KiB
is not the guest's RAM usage. Memory was sampled every five seconds; brief peaks
can be missed and process RSS sums double-count shared pages. No OOM matches
appeared in the final 4,000 current-boot kernel journal lines; that bounded
observation is not a universal proof that no OOM occurred.

## v19 correction and reviewed boundaries

Inactive units can be garbage-collected between separate systemctl and busctl
queries. The fix holds an owned harmless active oneshot reference with an
ordering-only `After=` link while inspecting the fixed Asterisk, ALLMODE digital
or stock MMDVM units. It never starts those target services. References span each
complete before/during/after comparison and fresh-profile operation. Exact owned
files are checked and removed; cleanup errors fail closed.

Stock evidence binds static condition definitions and configuration hashes,
not their disposable last-evaluation result. The separate harmless semantic
probe still requires the exact five-field failed condition, positive evaluation
timestamp, inactive state, zero PID and no ExecStart. This was independently
reviewed with 75 mocked/filesystem tests, then exercised in the actual recovery
run. Mock tests alone are not counted as commissioning.

## Immutable package set

| Package | Version | SHA-256 |
|---|---|---|
| ara-allmode (arm64) | 0.8.0~beta9-9 | 437b4cee9101b6abde68762f8e9940c9f8ee0a851882055054c9708d0d0df63c |
| ara-allmode-dvswitch-guard (all) | 0.8.0~beta9-2 | bcd272830d72e59e6859d20a8ae56e3995bd8ed9dd224bb70e601a24479d351e |
| ara-allmode-dvswitch (all) | 0.8.0~beta9-2 | 6df10c76bd036ee5e5f04eb3561964103308a04af161e5e9381b5a028d482162 |
| ara-allmode-meter (arm64) | 0.8.0~beta9+abid1486d408855-1 | b995666424613d3697bd6ade6e5075c2d316f95cc4e9c1520da148a7f26133bb |

The meter is qualified for the pinned ASL runtime/modules ABI
`2:22.10.1+asl3-3.10.8-1.deb13`, not arbitrary Asterisk releases.
Packaging source snapshot: `71115a6ebc65afde87ccdca4680eca6bd83e1f63f244f06cb30bbf860979c9a0`.
Core source: `1231449b471720cd09487599da11354d02d8e59d`.
Current signed Release: `2b8f1bdd24ad7fd96c80575d1d36acc2b6f6c3e4add0ca98f9320009c1ff2048`.
No package bytes were overwritten when revisions changed.

## Evidence and remaining limits

Internal retained evidence:
- `allmode-fresh-v18-pass.txt`
- `allmode-fresh-v18-512-pass.txt`
- `allmode-replay-v18-failure.txt` and its read-only diagnostic
- `allmode-replay-v19-pass.txt`
- `allmode-legacy-a-v19-failure.txt` and read-only diagnostic
- `allmode-legacy-a-v20-pass.txt`
- `allmode-legacy-b-v20-pass.txt`
- `allmode-targeted-fresh-readiness-v20-pass.txt`

Each test used one disposable ARM64 guest, a verified signed Debian image,
private extracted host tools, a separate disk and finite watchdog. No live Pi,
host package installation, host port forwarding or physical radio device was used.
The upstream netcheck reachability request was left unchanged and its outcome
recorded separately; no test-only mask was used to manufacture MMDVM inhibition.

Synthetic legacy tests are structural generic-bootstrap migration tests with
fake identities/authentication and preservation sentinels. They are not a claim
of every historical beta's behavior. The two actual Pi migrations used separate,
reviewed target-specific wrappers and preserved their own configurations.

Not qualified by this record: physical GPIO/UART/SHARI, RF or voice quality,
real Wi-Fi switching, iPhone/Safari LAN commissioning, every interruption point,
automatic rollback or unattended metadata renewal. Fresh access remains an
SSH-authenticated localhost tunnel. The optional LAN helper is not promoted by
these tests.

## Final candidate v20-r2 — exact tested scope

Exact archive SHA-256: `90ed40c1dfdbd109e8e86827e9b6042b1f93be40d4bde53b67cf1fa65c0e7f1f`.
Legacy A v19 exposed a restrictive-umask creation bug: the newly created `/etc/allmode` was mode 0700, preventing the unprivileged console from reading its configuration. V20 changes only that newly created nonsecret leaf to 0755; preexisting private directories are refused without modification. It also requires actual service-user configuration access, expected HTTP/auth responses and ownership of the exact configured listener by the stable console PID before removing guards or announcing readiness.

Independent review and 90 local tests passed, including real disposable socket ownership testing. Corrected A and B both passed in actual separate guests using the exact v20-r2 bundle. The final fresh-readiness function also passed on a separate clone of the previously qualified fresh v18 guest. That targeted run invoked only the imported production readiness function, not installation or resume; it preserved package versions, configuration content/ownership/modes, and stopped radio state. The original successful fresh-v18 disk remained unchanged. Prior v18/v19 transaction results above remain explicitly attributed to those versions; they are not relabeled as uninterrupted v20 runs. No full v20 fresh transaction, v20 512 MiB run or v20 reboot/resume run is claimed. Core9 package pins and the reviewed retention/recovery mechanisms are unchanged.

Durable log SHA-256 bindings for the new results:
- Legacy A v20: `60e06fd426d9d964be7385a361ce084df2fab88d9897886dfa8d6d308b34959c`.
- Legacy B v20: `72e155453b8a0192c8344f9a84e2b26205698c8879dcaece29c1190b15559d0e`.
- Targeted fresh-readiness v20: `20d26c9c47fc2b0ae21e4d0a895119dfa8933be23d8d01e7b827ca8e3682f275`; durable kind `targeted-fresh-readiness-not-full-install`, exit 0.

The requested scoped qualification gates are complete. Publication remains pending; this local artifact assigns no public installer download URL and does not itself authorize deployment or physical radio activation.
