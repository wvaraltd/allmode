# ALLMODE core9 installer — release preparation

**Qualification complete within the recorded scope; publication pending.** Corrected synthetic legacy A/B migrations and the targeted final fresh-readiness check passed. This local preparation does not claim the installer has been published.
Use only the authenticated release after publication is confirmed; consult
QUALIFICATION.md for the exact tested versions and limitations. No final download URL is assigned by this preparation document.
The inner installer archive is immutable; its historical README contains earlier
candidate results. This outer guide and QUALIFICATION.md state the current scope.

## Requirements and safety

- Debian 13, ARM64, working signed Debian repositories, Internet access and an
  existing administrator/SSH login. The installer creates no SSH password or key.
- Fresh mode requires no existing ASL or station configuration. Do not select it
  to erase an existing station. Existing package-managed ALLMODE is an upgrade,
  not a fresh or legacy migration target.
- Radio must be inactive. On an existing station, confirm RF is idle and explicitly
  stop radio services using its maintenance controls before proceeding. The
  installer refuses active Asterisk, ALLMODE digital or stock MMDVM services.
- Back up the station independently. The installer also creates root-private
  backups and a durable journal, but does not offer an automatic full rollback.
- Its signed packages include upstream MMDVM Bridge and dvswitch-base. Their
  authenticated maintainer scripts update host data, including some plain-HTTP
  downloads. The upstream netcheck service performs a fixed HTTPS reachability
  check. These are disclosed upstream effects, not radio connection commands.

## Verify, extract, inspect, install

Obtain this release through the project's authenticated release channel. Confirm
its expected digest through that trusted channel; a checksum downloaded beside
an unauthenticated script is not independent authentication. Never pipe a network
response directly into a root shell.

For the exact inner archive in this release:

```sh
printf '%s  %s\n' \
  90ed40c1dfdbd109e8e86827e9b6042b1f93be40d4bde53b67cf1fa65c0e7f1f \
  bootstrap-candidate-v20-r2.tar.gz | sha256sum -c -
mkdir allmode-installer-v20
tar -xzf bootstrap-candidate-v20-r2.tar.gz -C allmode-installer-v20
cd allmode-installer-v20
python3 bootstrap.py --mode fresh
sudo python3 bootstrap.py --mode fresh --apply
```

The first command prints the plan without installing. The second explicitly
applies it. Keep the extracted directory unchanged for recovery. Dependencies
are downloaded through authenticated APT and exact pinned closures; unrelated
upgrades, removals, unexpected trust changes and ABI mismatches are refused.
Do not bypass a failed signature, expired index or missing version.

Supported unpackaged legacy layouts use `--mode legacy-migrate`, not `fresh`.
That path passed the two corrected synthetic A/B migration cases on exact v20-r2.
This does not qualify every historical installation layout. It preserves
validated station/authentication/origin settings and backs up old code and units.
It does not automatically resume RF. Unknown layouts require review, not forced
flags or manual overwriting. The two real Pis were migrated using target-specific
reviewed wrappers, not evidence that every legacy layout is supported here.

## Open the console

On success, run the exact SSH tunnel command printed by the installer **on your
computer**, using the same existing login, host and SSH port. A typical command is:

```sh
ssh -N -L 8787:127.0.0.1:8787 LOGIN@HOST
```

Replace `LOGIN@HOST` with your existing SSH destination; retain `-p PORT` when
printed for a nonstandard SSH port. Keep that terminal open. In the computer's
browser open **http://127.0.0.1:8787/setup**. Complete Guided setup with your own
identity and radio settings, review/apply, and activate only when ready.

A fresh install leaves Asterisk disabled and radio/digital services stopped. The
fresh local-DVSwitch DMR preset does not invent IDs, credentials or enable a
network. DMR can use local DVSwitch; other supported modes remain their native
local software routes. M17 uses native Codec2.

This beta's fresh path is **SSH-tunnel/localhost only**. It does not silently open
an unauthenticated LAN listener, create TLS trust, configure a router, or claim
phone-ready LAN commissioning. Optional LAN and GPIO/UART procedures have
separate qualification limits. Physical SHARI, RF/audio and Wi-Fi switching are
not established by the virtual-machine tests.

## Interrupted installation

Keep the radio stopped and preserve the private backup/journal. Use the exact
resume command printed by the failed attempt, from the **identical authenticated
installer directory**, for example:

```sh
sudo python3 bootstrap.py --resume /var/backups/ara-allmode/bootstrap-TIMESTAMP --apply
```

Replace the example path with the exact printed path; never guess another
journal. Resume checks executable/support-file identity, intended package closure
and pending dpkg state. Do not edit journal hashes, substitute a newer bundle,
remove inhibition drop-ins, create the permit marker or run blanket
`dpkg --configure -a` to defeat a refusal. A journal from v18 or v19 cannot be resumed using v20. If the identical bundle still refuses, retain root-private `journal.json`
and `commands/*.json` for support; redact credentials before sharing logs.

One real v19 controlled interruption at `allmode-installed`, reboot and identical
bundle resume completed successfully. This is not a claim of exhaustive
power-loss testing at every possible instruction or an automatic rollback.

## Updates and repository expiry

`apt update` refreshes indexes; it does not install upgrades. Core updates require
the reviewed maintenance path and an idle radio. Do not assume an ordinary
unattended `apt upgrade` will safely stop an active transmitter.

The currently verified public metadata expires **2026-11-15 21:24:42 UTC**.
Installation/updates must fail closed after expiry until the repository operator
publishes newly signed metadata. Do not disable Valid-Until, allow unauthenticated
APT or use `trusted=yes`. No automatic metadata renewal has been installed.
The operator must coordinate renewal with the sole publisher, preserve immutable
package hashes and the existing signing key, verify both signatures and the full
index-to-package chain, and test external APT acceptance. The prepared renewal
utility still needs its own live dry-run/apply acceptance; its unit tests are not
proof of production renewal.

Archive signer: `59DAB5C15B5F96D5660E0D94503AE6F5AD483087`.
Repository: https://rf.ara.radio/allmode/apt/ .
