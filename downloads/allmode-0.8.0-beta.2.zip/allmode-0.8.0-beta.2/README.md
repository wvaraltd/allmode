# ARA ALLMODE 0.8.0-beta.1

Complete application install candidate for a fresh Debian 13 arm64 Raspberry Pi + SHARI HAT. Start with **BEGINNER-INSTALL.md**. Includes native digital source and build scripts, guided setup, HTTPS, dependencies, services, health checks and tester instructions.

Run `sudo bash install.sh --check`, then `sudo bash install.sh`. Internet is required. This is not an SD image or existing-node updater. No station credentials or preprogrammed radio settings are included.

Read VALIDATION.md for the remaining fresh-card and RF acceptance checks. See THIRD-PARTY.md for bundled upstream components and provenance.
