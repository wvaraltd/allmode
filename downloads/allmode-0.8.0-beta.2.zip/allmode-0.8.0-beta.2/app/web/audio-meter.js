(()=>{'use strict';
let busy=false,host=null,held={rx:-96,tx:-96},expires={rx:0,tx:0};
function mount(){
 const form=document.getElementById('audio-form');
 const dash=document.getElementById('dashboard-audio-meters');
 const target=form?form.parentElement:dash;
 if(!target)return null;
 let box=document.getElementById('live-audio-meters');
 if(box)return box;
 box=document.createElement('section');box.id='live-audio-meters';box.className='panel';
 box.classList.add('audio-console');
 box.innerHTML='<div class="audio-console-heading"><h2>RADIO AUDIO</h2><span class="audio-live-badge">LIVE LEVELS</span></div><div class="audio-meter-pair">'+['rx','tx'].map(k=>'<div class="audio-channel"><div class="audio-channel-heading"><span class="audio-channel-id">'+k.toUpperCase()+'</span><span>'+(k==='rx'?'RADIO → NETWORK':'NETWORK → RADIO')+'</span><strong id="meter-number-'+k+'">—</strong></div><div class="audio-led-track" id="meter-'+k+'" role="meter" aria-label="'+k.toUpperCase()+' audio RMS level" aria-valuemin="-60" aria-valuemax="0" aria-valuenow="-60">'+Array.from({length:30},()=>'<i></i>').join('')+'</div><div class="audio-scale"><span>−60</span><span>−48</span><span>−36</span><span>−24</span><span>−12</span><span>0 dBFS</span></div><p id="meter-text-'+k+'" class="audio-reading">Waiting for audio…</p></div>').join('')+'</div><div class="audio-console-footer"><span id="meter-state" role="status"></span>'+(dash?'<a href="/settings#audio">Audio settings & test →</a>':'<span>RF deviation · Not calibrated</span>')+'</div>'+(dash?'':'<details class="audio-meter-help"><summary>About these readings</summary><p>RMS audio and a two-second peak hold at the SimpleUSB audio path. CLIPPING indicates digital full scale; radio hardware can distort before this point. These are audio readings, not measured RF deviation. Calibration needs a known RX reference and an external TX deviation measurement.</p></details>');
 if(form)target.insertBefore(box,form);else target.append(box);
 held={rx:-96,tx:-96};expires={rx:0,tx:0};return box;
}
async function update(){
 if(busy||document.hidden)return;
 host=mount();if(!host)return;
 busy=true;const box=host;
 try{
  const r=await fetch('/api/audio-meter',{cache:'no-store'});if(!r.ok)throw Error('Audio meters unavailable');const s=await r.json();
  if(!box.isConnected)return;
  box.querySelector('#meter-state').textContent=s.active?'Live · listening only':s.error||'Audio meters unavailable';
  for(const k of ['rx','tx']){
   const v=s[k],fresh=s.active&&v?.available,now=Date.now();
   if(!fresh){held[k]=-96;expires[k]=0;}else if(v.peak_db>=held[k]||now>expires[k]){held[k]=v.peak_db;expires[k]=now+2000;}
   const level=fresh?Math.max(-60,v.rms_db):-60,track=box.querySelector('#meter-'+k);
   track.setAttribute('aria-valuenow',level.toFixed(1));
   const lit=Math.max(0,Math.ceil((level+60)/2)),peak=fresh&&held[k]>-60?Math.min(29,Math.floor((held[k]+60)/2)):-1;
   track.querySelectorAll('i').forEach((led,i)=>{led.classList.toggle('lit',i<lit);led.classList.toggle('peak',i===peak);});
   box.querySelector('#meter-number-'+k).textContent=fresh?(v.rms_db<=-96?'−∞':v.rms_db.toFixed(1)):'—';
   const text=box.querySelector('#meter-text-'+k);
   text.textContent=fresh?'RMS '+v.rms_db.toFixed(1)+' dBFS · Peak '+held[k].toFixed(1)+' dBFS'+(v.clipping?' · CLIPPING':''):(s.active?'Idle · no recent audio':'Unavailable');
   text.classList.toggle('audio-clipping',!!(fresh&&v.clipping));
  }
 }catch(e){if(box.isConnected){box.querySelector('#meter-state').textContent=e.message;for(const k of ['rx','tx']){box.querySelector('#meter-'+k).setAttribute('aria-valuenow','-60');box.querySelector('#meter-'+k).querySelectorAll('i').forEach(led=>led.classList.remove('lit','peak'));box.querySelector('#meter-number-'+k).textContent='—';box.querySelector('#meter-text-'+k).textContent='Unavailable';}}}
 finally{busy=false;}
}
setInterval(update,300);update();
})();
